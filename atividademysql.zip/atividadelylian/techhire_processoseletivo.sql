-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: techhire
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `processoseletivo`
--

DROP TABLE IF EXISTS `processoseletivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `processoseletivo` (
  `ID_Processo` int NOT NULL AUTO_INCREMENT,
  `ID_Candidato` int NOT NULL,
  `ID_Vaga` int NOT NULL,
  `Status` enum('Em análise','Triagem','Entrevista Técnica','Entrevista com empresa','Finalista','Aprovado','Reprovado') DEFAULT NULL,
  `DataAbertura` date DEFAULT NULL,
  `Ultimaatualizacao` datetime DEFAULT NULL,
  PRIMARY KEY (`ID_Processo`),
  KEY `IX_PS_Candidato` (`ID_Candidato`),
  KEY `IX_PS_Vaga` (`ID_Vaga`),
  CONSTRAINT `FK_PS_Candidato` FOREIGN KEY (`ID_Candidato`) REFERENCES `candidato` (`ID_Candidato`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_PS_Vaga` FOREIGN KEY (`ID_Vaga`) REFERENCES `vaga` (`ID_Vaga`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `processoseletivo`
--

LOCK TABLES `processoseletivo` WRITE;
/*!40000 ALTER TABLE `processoseletivo` DISABLE KEYS */;
INSERT INTO `processoseletivo` VALUES (1,1,1,'Entrevista Técnica','2026-01-10','2026-01-15 10:00:00'),(2,2,2,'Em análise','2026-01-12','2026-01-13 09:30:00'),(3,3,3,'Aprovado','2026-01-05','2026-01-20 15:45:00'),(4,5,2,'Finalista','2026-01-08','2026-01-19 11:20:00'),(5,4,5,'Em análise','2026-01-18','2026-01-18 08:00:00');
/*!40000 ALTER TABLE `processoseletivo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02 17:39:27
