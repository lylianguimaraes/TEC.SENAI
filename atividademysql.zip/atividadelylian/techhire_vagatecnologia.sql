-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: techhire
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vagatecnologia`
--

DROP TABLE IF EXISTS `vagatecnologia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vagatecnologia` (
  `ID_Vaga` int NOT NULL,
  `ID_Tecnologia` int NOT NULL,
  `NivelMinimo` enum('Básico','Intermediário','Avançado') NOT NULL,
  PRIMARY KEY (`ID_Vaga`,`ID_Tecnologia`),
  KEY `FK_VT_Tecnologia` (`ID_Tecnologia`),
  CONSTRAINT `FK_CT_Vaga` FOREIGN KEY (`ID_Vaga`) REFERENCES `vaga` (`ID_Vaga`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_VT_Tecnologia` FOREIGN KEY (`ID_Tecnologia`) REFERENCES `tecnologia` (`ID_Tecnologia`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vagatecnologia`
--

LOCK TABLES `vagatecnologia` WRITE;
/*!40000 ALTER TABLE `vagatecnologia` DISABLE KEYS */;
INSERT INTO `vagatecnologia` VALUES (1,1,'Avançado'),(1,3,'Intermediário'),(1,5,'Intermediário'),(2,1,'Intermediário'),(2,2,'Básico'),(2,3,'Avançado'),(3,4,'Avançado'),(3,6,'Avançado'),(4,2,'Avançado'),(4,3,'Intermediário'),(4,4,'Básico'),(5,1,'Básico'),(5,3,'Avançado');
/*!40000 ALTER TABLE `vagatecnologia` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02 17:39:26
