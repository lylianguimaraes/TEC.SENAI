-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: techhire
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vw_vagasqueexigemsql`
--

DROP TABLE IF EXISTS `vw_vagasqueexigemsql`;
/*!50001 DROP VIEW IF EXISTS `vw_vagasqueexigemsql`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_vagasqueexigemsql` AS SELECT 
 1 AS `Titulo`,
 1 AS `NomeEmpresa`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_candidatosexperientes`
--

DROP TABLE IF EXISTS `vw_candidatosexperientes`;
/*!50001 DROP VIEW IF EXISTS `vw_candidatosexperientes`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_candidatosexperientes` AS SELECT 
 1 AS `Nome`,
 1 AS `Email`,
 1 AS `ExperienciaAnos`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_candidatosphytonavancado`
--

DROP TABLE IF EXISTS `vw_candidatosphytonavancado`;
/*!50001 DROP VIEW IF EXISTS `vw_candidatosphytonavancado`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `vw_candidatosphytonavancado` AS SELECT 
 1 AS `Nome`,
 1 AS `Email`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_vagasqueexigemsql`
--

/*!50001 DROP VIEW IF EXISTS `vw_vagasqueexigemsql`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_vagasqueexigemsql` AS select `v`.`Titulo` AS `Titulo`,`e`.`NomeEmpresa` AS `NomeEmpresa` from (((`vaga` `v` join `empresa` `e` on((`v`.`ID_Empresa` = `e`.`ID_Empresa`))) join `vagatecnologia` `vt` on((`v`.`ID_Vaga` = `vt`.`ID_Vaga`))) join `tecnologia` `t` on((`t`.`ID_Tecnologia` = `vt`.`ID_Tecnologia`))) where (`t`.`NomeTecnologia` = 'SQL') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_candidatosexperientes`
--

/*!50001 DROP VIEW IF EXISTS `vw_candidatosexperientes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_candidatosexperientes` AS select `candidato`.`Nome` AS `Nome`,`candidato`.`Email` AS `Email`,`candidato`.`ExperienciaAnos` AS `ExperienciaAnos` from `candidato` where (`candidato`.`ExperienciaAnos` > 3) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_candidatosphytonavancado`
--

/*!50001 DROP VIEW IF EXISTS `vw_candidatosphytonavancado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_candidatosphytonavancado` AS select `c`.`Nome` AS `Nome`,`c`.`Email` AS `Email` from ((`candidato` `c` join `candidatotecnologia` `ct` on((`c`.`ID_Candidato` = `ct`.`ID_Candidato`))) join `tecnologia` `t` on((`t`.`ID_Tecnologia` = `ct`.`ID_Tecnologia`))) where ((`t`.`NomeTecnologia` = ' Phyton') and (`ct`.`Nivel` = 'Avançado')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02 17:39:27
